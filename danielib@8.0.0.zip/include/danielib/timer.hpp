#pragma once

namespace danielib {
class Timer {
    public:
        Timer();
};
}