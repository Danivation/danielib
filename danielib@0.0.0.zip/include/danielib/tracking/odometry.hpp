#pragma once
#include "pros/rotation.hpp"

namespace danielib {
/**
 * @brief Class for adding odometry to a drivetrain
 */
class odometry {
    public:
        // whatever
    private:
        // something
};
} // namespace danielib