#pragma once
#include "pros/motors.h"

namespace danielib {
/**
 * @brief Creates a drivetrain object
 */
class drivetrain {
    public:
        drivetrain(/* args */);
    private:
        /* data */
};
} // namespace danielib
